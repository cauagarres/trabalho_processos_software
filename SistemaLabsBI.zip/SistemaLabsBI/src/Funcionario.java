import java.util.ArrayList;

public abstract class Funcionario {

    // ============================
    // Atributos comuns a todo funcionário
    // ============================
    protected int matricula;
    protected String nome;
    protected String usuario;
    protected String funcao;
    protected String setor;
    protected String cpf;
    protected int data_admissao;
    protected String email;
    protected String senha;
    protected boolean ativo;
    protected String nivelAcesso;

    // ============================
    // Construtor
    // ============================
    public Funcionario(int matricula, String nome, String usuario , String funcao,
                       String setor, String cpf, int data_admissao, String email,
                       String senha, String nivelAcesso){

        this.matricula = matricula;
        this.nome = nome;
        this.usuario = usuario;
        this.funcao = funcao;
        this.setor = setor;
        this.cpf = cpf;
        this.data_admissao = data_admissao;
        this.email = email;
        this.senha = senha;
        this.nivelAcesso = nivelAcesso;
        this.ativo = true;  // Todo funcionário é criado como ativo
    }


    // ============================
    // GETTERS e SETTERS
    // ============================

    public int getMatricula() { return matricula; }

    public void setMatricula(int matricula) { this.matricula = matricula; }

    public boolean getAtivo() { return ativo; }

    public void setAtivo(boolean ativo) { this.ativo = ativo; }

    public String getSenha() { return senha; }

    public void setSenha(String senha) { this.senha = senha; }

    public int getData_admissao() { return data_admissao; }

    public void setData_admissao(int data_admissao) { this.data_admissao = data_admissao; }

    public String getEmail() { return email; }

    public void setEmail(String email) { this.email = email; }

    public String getCpf() { return cpf; }

    public void setCpf(String cpf) { this.cpf = cpf; }

    public String getSetor() { return setor; }

    public void setSetor(String setor) { this.setor = setor; }

    public String getFuncao() { return funcao; }

    public void setFuncao(String funcao) { this.funcao = funcao; }

    public String getNome() { return nome; }

    public void setNome(String nome) { this.nome = nome; }

    public String getUsuario() { return usuario; }

    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getNivelAcesso() { return nivelAcesso; }

    public void setNivelAcesso(String nivelAcesso) { this.nivelAcesso = nivelAcesso; }
}
