import java.util.ArrayList;

public class Administrador extends Funcionario {

    // ============================
    // Lista de usuários do sistema
    // Todo administrador tem acesso
    // ============================
    private static ArrayList<Usuario> listaUsuarios = new ArrayList<>();


    // ============================
    // Construtor
    // ============================
    public Administrador(int matricula, String nome, String usuario , String funcao,
                         String setor, String cpf, int data_admissao, String email,
                         String senha, String nivelAcesso){
        super(matricula, nome, usuario, funcao, setor, cpf, data_admissao, email, senha, nivelAcesso);
    }


    // ============================
    // Método para adicionar um novo usuário ao sistema
    // ============================
    public void adicionarUsuario(int matricula, String nome, String usuario , String funcao, String setor,
                                 String cpf, int data_admissao, String email, String senha, String nivelAcesso){

        Usuario novoUsuario = new Usuario(matricula, nome, usuario, funcao, setor, cpf,
                data_admissao, email, senha, nivelAcesso);

        listaUsuarios.add(novoUsuario);
        System.out.println("Usuário " + nome + " adicionado com sucesso!");
    }


    // ============================
    // Resetar senha de qualquer usuário
    // ============================
    public void resetarSenha(Usuario usuario){
        usuario.setSenha("mudarsenha123");
        System.out.println("Senha resetada para o usuário: " + usuario.getNome());
    }


    // ============================
    // Método para listar todos os usuários cadastrados
    // ============================
    public void listarUsuarios(){
        System.out.println("===== LISTA DE USUÁRIOS =====");
        for (Usuario u : listaUsuarios){
            System.out.println("Nome: " + u.getNome() + " | Usuário: " + u.getUsuario());
        }
    }
}
