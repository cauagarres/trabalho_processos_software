public class Usuario extends Funcionario {

    // ============================
    // Construtor
    // ============================
    public Usuario(int matricula, String nome, String usuario, String funcao,
                   String setor, String cpf, int data_admissao, String email,
                   String senha, String nivelAcesso) {

        super(matricula, nome, usuario, funcao, setor, cpf, data_admissao, email, senha, nivelAcesso);
    }

    // ============================
    // Método de login
    // Agora usando "this"
    // ============================
    public void realizarLogin(String usuarioDigitado, String senhaDigitada){
        boolean efetivacao = this.usuario.equals(usuarioDigitado)
                && this.senha.equals(senhaDigitada)
                && this.ativo;

        if (efetivacao){
            System.out.println("Login realizado com sucesso!");
        } else {
            System.out.println("Usuário ou senha incorretos.");
        }
    }

    // ============================
    // Métodos de edição de dados
    // Agora funcionando corretamente
    // ============================

    public void editarNome(String novoNome){
        this.nome = novoNome;
    }

    public void editarEmail(String novoEmail){
        this.email = novoEmail;
    }

    public void editarSenha(String novaSenha){
        this.senha = novaSenha;
    }
}
