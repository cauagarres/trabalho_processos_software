// --- VISIBILIDADE SENHA ---

function togglePassword(inputId, iconElement) {
    const input = document.getElementById(inputId);

    if (input.type === "password") {
        input.type = "text";

        iconElement.classList.remove("fa-eye-slash");
        iconElement.classList.add("fa-eye");
    } else {
        input.type = "password";

        iconElement.classList.remove("fa-eye");
        iconElement.classList.add("fa-eye-slash");
    }
}

document.addEventListener('DOMContentLoaded', function() {

    // --- FUNÇÃO EXPORTAR PDF ---
    const btnPdf = document.getElementById('btn-pdf');
    if(btnPdf) {
        btnPdf.addEventListener('click', function() {
            window.print(); // Abre a janela nativa de impressão
        });
    }

    // --- FUNÇÃO EXPORTAR EXCEL ---
    const btnExcel = document.getElementById('btn-excel');
    if(btnExcel) {
        btnExcel.addEventListener('click', function() {
            var table = document.querySelector(".full-table");
            var html = table.outerHTML;

            // Cria um link temporário para download
            var url = 'data:application/vnd.ms-excel,' + encodeURIComponent(html);
            var downloadLink = document.createElement("a");
            
            document.body.appendChild(downloadLink);
            downloadLink.href = url;
            downloadLink.download = "relatorio_vendas.xls";
            
            downloadLink.click();
            document.body.removeChild(downloadLink);
        });
    }

});