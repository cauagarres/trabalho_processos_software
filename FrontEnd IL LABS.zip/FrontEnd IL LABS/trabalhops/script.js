function togglePassword(inputId, iconElement) {
    const input = document.getElementById(inputId);

    if (input.type === "password") {
        input.type = "text";

        iconElement.classList.remove("fa-eye-slash");
        iconElement.classList.add("fa-eye");
    } else {
        input.type = "password";

        iconElement.classList.remove("fa-eye");
        iconElement.classList.add("fa-eye-slash");
    }
}